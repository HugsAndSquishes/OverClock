from django.urls import path
from . import views

urlpatterns = [
    path('clock/', views.clock_action, name='clock-action'),
]
