from rest_framework import serializers
from .models import ClockLog

class ClockLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = ClockLog
        fields = '__all__'
